x=msgbox("Microsoft is currently scanning for viruses..." ,48, "Microsoft") 

